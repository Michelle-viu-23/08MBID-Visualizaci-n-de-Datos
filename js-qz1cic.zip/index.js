// Import stylesheets
import './style.css';

// Write Javascript code!
const appDiv = document.getElementById('app');